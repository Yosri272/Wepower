<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SupportTicket\\App\\Providers\\SupportTicketServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SupportTicket\\App\\Providers\\SupportTicketServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);