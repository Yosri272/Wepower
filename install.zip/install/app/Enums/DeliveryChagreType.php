<?php

namespace App\Enums;

enum DeliveryChagreType: string
{
    case PERORDER = 'Per Order';
    case PERPRODUCT = 'Per Product';
}
