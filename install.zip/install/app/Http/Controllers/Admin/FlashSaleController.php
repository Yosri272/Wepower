<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

class FlashSaleController extends Controller
{
    //
}
